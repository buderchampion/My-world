import json
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent

WAGES = DATA_DIR / "NPCS" / "Wages.json"
CITY_PAY_SCALING = DATA_DIR / "Buildings" / "CityPayScaling.json"

# Exponential leveling curve -- easy to retune later without touching
# any of the logic below. xp needed to go from `level` to `level + 1`.
BASE_LEVEL_XP = 100
LEVEL_XP_GROWTH = 1.5

# Flat xp granted per skill per workday, before the city's xp_multiplier.
SKILL_XP_PER_DAY = 10


from functools import lru_cache


@lru_cache(maxsize=None)
def load_json(file):

    with open(file, "r") as f:
        return json.load(f)


def xp_to_next_level(level):

    return round(BASE_LEVEL_XP * (LEVEL_XP_GROWTH ** (level - 1)))


def get_wage(profession, city_type):

    wages = load_json(WAGES)
    scaling = load_json(CITY_PAY_SCALING)

    base_wage = wages.get(profession, 0)

    multiplier = scaling.get(city_type, {}).get("wage_multiplier", 1.0)

    return round(base_wage * multiplier, 2)


def add_skill_xp(skill, amount):

    # skill is one of the npc["skills"][name] dicts -- mutated in place.
    skill["xp"] += amount

    while skill["xp"] >= xp_to_next_level(skill["level"]):
        skill["xp"] -= xp_to_next_level(skill["level"])
        skill["level"] += 1


def apply_workday(npc, tax_rate: float = 0.0) -> float:
    """
    Applies a single day of work to an npc: adds their after-tax wage
    to gold, and grants xp to every skill their class gave them (if
    any), scaled by their city's pay tier. Returns the tax amount
    collected (0 if tax_rate is 0, the default), so a caller can route
    it to the kingdom's treasury.
    """

    scaling = load_json(CITY_PAY_SCALING)

    city_type = npc.get("city_type")

    xp_multiplier = scaling.get(city_type, {}).get("xp_multiplier", 1.0)

    wage = get_wage(npc["profession"], city_type)

    tax = round(wage * tax_rate, 2)
    take_home = round(wage - tax, 2)

    npc["gold"] = round(npc.get("gold", 0) + take_home, 2)

    for skill in npc.get("skills", {}).values():
        add_skill_xp(skill, round(SKILL_XP_PER_DAY * xp_multiplier))

    return tax
